# Labels

* TODO: Define label syntax (e.g., `[a-z]...`).
* TODO: Once decided on a generic labeling syntax (`{LABEL:}`), document here.

Body nodes may generally be labeled, in which case one may
[reference](../text.md#references) them.

Labeling is only possible if the respective node has an
[output identifier](./identifier.md#output-identifiers).
